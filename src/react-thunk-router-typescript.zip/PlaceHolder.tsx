import React, {useContext} from 'react';
import CounterExample from "./CounterExample";
import {UserType, UserContext} from "./App";
import {useSelector} from "react-redux";
import {RootState} from "./store";

const PlaceHolder: React.FC = (): JSX.Element =>
{
    const calcValues = useSelector((state: RootState) => state.calc);

    const { name,surname,setName,setSurname } = useContext<UserType>(UserContext);

    return <div>
                <h3>Result : {calcValues.total}</h3>
                <p>Users :{name}: placeholder</p>
            </div>
}
export default PlaceHolder;