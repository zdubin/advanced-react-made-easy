import { useCallback, useState , useContext} from "react";
import React from 'react';
import {UserType, UserContext} from "./App";

type CounterExampleProps = {
    initialValue: number;
}
const  CounterExample: React.FC<CounterExampleProps> = ({initialValue}: CounterExampleProps): JSX.Element => {
    const [counter, setCounter] = useState<number>(initialValue);
    const { name,surname,setName,setSurname } = useContext<UserType>(UserContext);

    const handleName = (n: string) => {
        if (setName)
             setName(n);
        }

    const handleIncrement = useCallback(() => {
        setCounter((prev: number    ) => prev + 1);
        // Dependency removed!
    }, []);

    const handleDelayedIncrement = useCallback(() => {
        // Using prev state helps us to avoid unexpected behaviour
        setTimeout(() => setCounter((prev: number) => prev + 1), 1000);
        // Dependency removed!
    }, []);

    return (
        <div>
            <h1>{`Counter is ${counter}`}</h1>
            <h2>{`Name is ${name}`}</h2>
            <button onClick={handleIncrement}>Instant increment</button>
            <button onClick={handleDelayedIncrement}>Delayed increment</button>
            <button onClick={() => handleName(`${name}${counter}`)}>Name Change</button>
        </div>
    );
}
export default CounterExample;