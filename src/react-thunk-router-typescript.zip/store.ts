import {configureStore, Dispatch, MiddlewareAPI} from '@reduxjs/toolkit';
import calcReducer from './CalcSlice';
import {load_articles} from './CalcSlice';

export const myLoggingMiddleware =  ({ dispatch, getState }: MiddlewareAPI) =>  (next: Dispatch) => (action: any) => {
    // Here you have access to `action.type` and `action.payload`
    console.log('Logging action with type', action.type);

    if (action.type !== 'calc/load_articles')
      fetch('https://newsapi.org/v2/everything?q=tech&apiKey=c8ed61ab623e44c7af2bec4299313dd8')
        .then((response) => response.json())
        .then((json) => {
            dispatch(load_articles( json.articles.map((row: any) => row.title)));
            return next(action);
        })
        .catch((error) => {
            console.error(error);
            return next(action);
            }
        )
    else
        return next(action);

    /*
        setTimeout(() =>{ console.log('Logging action with type', action.type);
            console.log('Logging action with payload', action.payload);
            return next(action);
            },500)
    */
    // You should always do this at the end of your middleware
   // return next(action)
}

export const store = configureStore({
    reducer: {
        calc: calcReducer,
        // @ts-ignore
    },
    middleware: getDefaultMiddleware => getDefaultMiddleware().concat(myLoggingMiddleware),

});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
