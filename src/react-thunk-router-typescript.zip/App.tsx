import React, {lazy,Suspense,createContext, Dispatch, SetStateAction, useContext, useMemo, useState, ReactNode} from "react";
import logo from './logo.svg';
import './App.css';
//import CounterExample from './CounterExample';
// @ts-ignore
import {BrowserRouter as Router, Routes, Route, Link, useLocation, Outlet, useOutletContext,NavLink} from "react-router-dom";
import {
    Nav,
    NavItem,
    Dropdown,
    DropdownItem,
    DropdownToggle,
    DropdownMenu,

} from 'reactstrap';
import {Provider, useSelector} from 'react-redux';
import {RootState, store} from './store';
import CalcPage from './CalcPage';


//import PlaceHolder from './PlaceHolder';
const CounterExamplePreview = lazy(() => import('./CounterExample'));
const PlaceHolderPreview = lazy(() => import('./PlaceHolder'));
/*
const PlaceHolderPreview = lazy(async () => {
    return {
        default: (import('./PlaceHolder'))).PlaceHolder
    }
})
*/


export type UserType = {
    name: string,
    surname: string,
    setName?: Dispatch<SetStateAction<string>>,
    setSurname?: Dispatch<SetStateAction<string>>
}
export const UserContext = createContext<UserType>({name: '', surname: ''});

type childProps = {
    children: ReactNode | undefined
}

// That component separates user context from app, so we don't pollute it
const UserContextProvider = ({children}: childProps) => {
    const [name, setName] = useState<string>("Pavel");
    const [surname, setSurname] = useState<string>("Pogosov");


    // We want to remember value reference, otherwise we will have unnecessary rerenders
    /*
      const value:UserType =
          {
            name,surname,setName,setSurname
          }
    */
    /*
    const value = {
        name,
        surname,
        setName,
        setSurname
    };
*/
    const value =
        useMemo(() => {
            return {
                name,
                surname,
                setName,
                setSurname
            };
        }, [name, surname]);

    return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
}

function PageFirst() {
    const {name} = useContext(UserContext);

    return name;
}

function PageSecond() {
    const {surname} = useContext(UserContext);

    return surname;
}

function App() {


    setTimeout(() => console.log(1), 0);

    console.log(2);

    new Promise<void>(res => {
        console.log(3)
        res();
    }).then(() => console.log(4));

    console.log(5);

    const matchPath = (path: string): boolean => window.location.href.split('/').slice(-1)[0] === path;

    /*
        const location = useLocation();
    console.log(location)
    */
    // @ts-ignore
    // @ts-ignore
    return (
        <Provider store={store}>

        <UserContextProvider>

        <Router>
                <>
                    <NavLink to="/"
                    >
                        Home
                    </NavLink>
                            <NavLink to="/index"
                            >
                                Counter
                            </NavLink>

                                <NavLink to="/users"
                            >
                                Users
                            </NavLink>
                    <NavLink to="/calc"
                    >
                        Calc
                    </NavLink>
                    <Routes>

                            <Route path="/index" element={
                                <div className="App">
                                    <Suspense fallback={<p>Loading...</p>}>
                                        <h2>Preview</h2>
                                        <CounterExamplePreview initialValue={0}/>
                                    </Suspense>
                                </div>}>
                            </Route>

                            <Route path="/users" element={
                                <Suspense fallback={<p>Loading...</p>}>
                                    <h2>Preview</h2>
                                    <PlaceHolderPreview/>
                                </Suspense>}>
                            </Route>
                            <Route path="/" element={
                                <p>Home Sweet Home...</p>}>
                            </Route>
                        <Route path="/calc" element={
                            <CalcPage/>}>
                        </Route>
                        </Routes>

                </>
            </Router>
        </UserContextProvider>
        </Provider>
);
}

export default App;
